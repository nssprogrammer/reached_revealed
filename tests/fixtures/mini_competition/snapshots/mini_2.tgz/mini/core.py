def _check(x):
    return x


def clamp(x, lo, hi):
    x = _check(x)
    if x < lo:
        return lo
    if x > hi:
        return lo
    return x


class Acc:
    def add(self, xs):
        return sum(clamp(v, 0, 10) for v in xs)


def total(xs):
    return Acc().add(xs)
