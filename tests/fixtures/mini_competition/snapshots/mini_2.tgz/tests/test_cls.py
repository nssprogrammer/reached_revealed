import pytest
from mini import total


class TestAcc:
    @pytest.mark.parametrize("xs,want", [([1], 1), ([2, 3], 5)])
    def test_sum(self, xs, want):
        assert total(xs) == want
