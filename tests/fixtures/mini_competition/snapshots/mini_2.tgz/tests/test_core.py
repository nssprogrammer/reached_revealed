import pytest
from mini import clamp, total


def test_low():
    assert clamp(-5, 0, 10) == 0


@pytest.mark.xdist_group("g")
def test_mid():
    assert clamp(5, 0, 10) == 5


def test_total_small():
    assert total([1, 2]) == 3
